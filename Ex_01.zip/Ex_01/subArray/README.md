# Ex 1
Cho 2 array, kiểm tra mảng này có phải là mảng con của mảng kia không
Ví dụ:
        `let org_arr = [1, 2, 3, 5, 6, 8, 10, 11];`
        `let sub_arr = [6, 8, 10];`

