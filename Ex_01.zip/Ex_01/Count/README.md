# Ex2
Cho 1 chuỗi string Slice như dưới đây. Nhập 1 từ bất kỳ từ bàn phím, in ra số lượng từ này xuất hiện trong chuỗi đã cho.
 `https://ars.els-cdn.com/content/image/1-s2.0-S0960982203005347-mmc6.txt`

