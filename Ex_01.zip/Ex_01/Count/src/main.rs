use std::io::stdin;
use regex::Regex;

#[derive(PartialEq)]
enum SearchType {
    Absolute,
    Relative,
    Regex,
}
const FIXED_STR: &str =
    "https://ars.els-cdn.com/content/image/1-s2.0-S0960982203005347-mmc6.Txtx";
// const FIXED_STR_TO_SEARCH_REGEX: &str = "This is foo and FOO foo as well as FoO.";

fn main() {
    let input = input("Enter word to search", None);
    let raw_search_type = input_with_loop(
        "\nEnter type of search",
        Some("\t1: Absolute\n\t2: Relative\n\t3: Regex"),
    );

    let number_of_word = count_word_with_specific_type(&input, _enum(&raw_search_type));
    println!("Number of matches: {:#?}", number_of_word);
}

/**
 * Input
 */
fn input(message: &str, instruction: Option<&str>) -> String {
    let mut line: String = String::new();
    println!("{}:", message);

    match instruction {
        Some(ins) => println!("{}", ins),
        None => (),
    }

    stdin().read_line(&mut line).unwrap();
    line.pop();

    line
}

/**
 * Loop until enter the right value
 */
fn input_with_loop(message: &str, instruction: Option<&str>) -> String {
    let absolute: &str = "1";
    let relative: &str = "2";
    let regex: &str = "3";

    loop {
        let mut line = String::new();
        println!("{}:", message);

        match instruction {
            Some(_instruction) => println!("{}", _instruction),
            None => (),
        }

        stdin().read_line(&mut line).unwrap();
        line.pop().unwrap();

        if line == absolute || line == relative || line == regex {
            return line;
        } else {
            println!("Try again!\n")
        }
    }
}

/**
 * Searching function
 */
fn count_word_with_specific_type(input: &str, search_type: SearchType) -> u32 {
    let mut number_of_matches: u32 = 0;
    let mut _FIXED_STR: Vec<char> = Vec::new();
    let mut _input: Vec<char> = Vec::new();

    match search_type {
        SearchType::Relative => {
            _FIXED_STR = split_to_letter(&FIXED_STR.to_lowercase());
            _input = split_to_letter(&input.to_lowercase());
        }
        SearchType::Absolute => {
            _FIXED_STR = split_to_letter(&FIXED_STR);
            _input = split_to_letter(&input);
        }
        SearchType::Regex => {
            return search_by_regex(input);
        }
    }

    for frame in _FIXED_STR.windows(_input.len()) {
        if frame == _input {
            number_of_matches = number_of_matches + 1;
        }
    }

    number_of_matches
}

/**
 * Search by regex
 */
fn search_by_regex(regex: &str) -> u32 {
    // regex = (?i)foo // sample input regex
    let _regex: Regex = Regex::new(regex).unwrap();
    _regex.find_iter(FIXED_STR).count() as u32
}

/**
 * Split input string into Vector
 */
fn split_to_letter(value: &str) -> Vec<char> {
    let mut result: Vec<char> = Vec::new();

    for char in value.chars() {
        result.push(char);
    }

    result
}

/**
 * Convert raw_string to enum type
 */
fn _enum(raw_string: &str) -> SearchType {
    match raw_string {
        "1" => SearchType::Absolute,
        "2" => SearchType::Relative,
        "3" => SearchType::Regex,
        _ => panic!("The value is not in range"),
    }
}
