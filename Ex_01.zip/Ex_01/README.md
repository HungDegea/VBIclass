# Description

# Ex
## Ex 1
Cho 2 array, hãy kiểm tra mảng này có phải là mảng con của mảng kia không
Ví dụ : 
    let org_arr = [1, 2, 3, 5, 6, 8, 10, 11];
    let sub_arr = [6, 8, 10];

## Ex2
Cho 1 chuỗi string Slice như dưới. Nhập 1 từ bất kỳ từ bàn phím, in ra số lượng từ này xuất hiện trong chuỗi đã cho
    `https://ars.els-cdn.com/content/image/1-s2.0-S0960982203005347-mmc6.txt`

